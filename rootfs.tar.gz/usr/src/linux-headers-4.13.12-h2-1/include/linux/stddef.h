

#ifndef __always_inline
#define __always_inline __inline__
#endif
