#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element::Teletype::Error;
use strict;
use base qw(Debconf::Element::Teletype::Text);


1
